//Programmers: Parsa Divanbeigi(pdcbc) and Raphael Seymour(rns2p2) Section: 101
#include "jewel.h"
#include <iostream>

using namespace std;
Jewel::Jewel() {

}
Jewel::Jewel(int x, int y, int val) {
    Xcor = x;
    Ycor = y;
    val = x+y;

}

int Jewel::getXocr() {
    return Xcor;
}

int Jewel::getYcor(){
    return Ycor;
}

int Jewel::getVal() {
    return val;
}